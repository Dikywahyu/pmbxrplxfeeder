<ul id="sidebarnav" class="sidebar-nav">
    <?php
        $currentCategory = null;
    ?>

    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <?php if(isset($menu['category']) && $menu['category'] !== $currentCategory): ?>
            <?php $currentCategory = $menu['category']; ?>
            <li class="nav-small-cap">
                <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
                <span class="hide-menu text-uppercase fw-bold fs-2"><?php echo e($currentCategory); ?></span>
            </li>
        <?php endif; ?>

        
        <li class="sidebar-item <?php echo e(($menu['active'] ?? false) ? 'active' : ''); ?>">
            <a class="sidebar-link <?php echo e($menu['class'] ?? ''); ?>" 
               href="<?php echo e($menu['url']); ?>" 
               aria-expanded="false">
                
                <?php if(str_contains($menu['icon'] ?? '', ':')): ?>
                    <iconify-icon icon="<?php echo e($menu['icon']); ?>" class="fs-6"></iconify-icon>
                <?php else: ?>
                    <i class="<?php echo e($menu['icon'] ?? 'ti ti-circle'); ?>"></i>
                <?php endif; ?>
                
                <span class="hide-menu"><?php echo e($menu['title']); ?></span>
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH C:\xampp\htdocs\pmb\resources\views\layouts\partials\menu-data.blade.php ENDPATH**/ ?>