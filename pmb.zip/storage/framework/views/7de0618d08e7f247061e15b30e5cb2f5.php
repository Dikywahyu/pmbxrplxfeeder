<?php $__empty_1 = true; $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <span class="badge bg-light text-dark border me-1 mb-1"><?php echo e($path->nama_jalur); ?></span>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-muted small mb-0">Belum ada jalur pendaftaran.</p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\paths.blade.php ENDPATH**/ ?>