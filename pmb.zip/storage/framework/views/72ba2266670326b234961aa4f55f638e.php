<?php $__env->startSection('title', 'Hasil Ujian CBT'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4"><div><h4 class="fw-semibold mb-1">Hasil: <?php echo e($exam->title); ?></h4><p class="text-muted mb-0">Periksa jawaban esai dan beri nilai manual.</p></div><a class="btn btn-light" href="<?php echo e(route('admin.cbt.index')); ?>">Kembali</a></div>
    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $exam->attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card"><div class="card-body"><div class="d-flex justify-content-between flex-wrap"><div><h5><?php echo e($attempt->registration->candidate?->nama_mahasiswa ?? 'Pendaftar'); ?></h5><p class="text-muted"><?php echo e($attempt->registration->nomor_pendaftaran); ?> · <?php echo e($attempt->status); ?> · Mulai <?php echo e($attempt->started_at->format('d/m/Y H:i')); ?></p></div><span class="badge bg-primary align-self-start">Nilai saat ini: <?php echo e($attempt->score); ?></span></div>
            <?php $__currentLoopData = $attempt->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border rounded p-3 mb-3"><div class="d-flex justify-content-between"><strong><?php echo e($answer->question->type === 'essay' ? 'Esai' : 'Pilihan ganda'); ?> · <?php echo e($answer->question->points); ?> poin</strong><span>Nilai: <?php echo e($answer->score ?? 'Belum dinilai'); ?></span></div><p class="mb-2 mt-2"><?php echo e($answer->question->question_text); ?></p>
                    <?php if($answer->question->type === 'essay'): ?>
                        <div class="bg-light rounded p-3 mb-2"><?php echo e($answer->answer_text ?: 'Tidak ada teks jawaban.'); ?></div>
                        <?php if($answer->answer_image_path): ?><a href="<?php echo e(asset('storage/'.$answer->answer_image_path)); ?>" target="_blank">Lihat gambar jawaban</a><?php endif; ?>
                        <form method="POST" action="<?php echo e(route('admin.cbt.answers.grade', $answer->id)); ?>" class="row g-2 mt-2"><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><div class="col-md-2"><input class="form-control" type="number" name="score" min="0" max="<?php echo e($answer->question->points); ?>" step="0.01" value="<?php echo e($answer->score); ?>" placeholder="Nilai" required></div><div class="col-md-7"><input class="form-control" name="grader_note" value="<?php echo e($answer->grader_note); ?>" placeholder="Catatan penilai"></div><div class="col-md-3"><button class="btn btn-primary">Simpan nilai</button></div></form>
                    <?php else: ?>
                        <p class="mb-0">Jawaban: <strong><?php echo e($answer->selected_option ?? 'Tidak dijawab'); ?></strong> · Kunci: <?php echo e($answer->question->correct_option); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="card"><div class="card-body text-muted">Belum ada peserta yang memulai ujian.</div></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\cbt\attempts.blade.php ENDPATH**/ ?>