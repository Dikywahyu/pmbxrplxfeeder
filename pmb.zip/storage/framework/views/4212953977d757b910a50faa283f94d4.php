<?php echo e($registrations->links()); ?>

<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\registration-pagination.blade.php ENDPATH**/ ?>