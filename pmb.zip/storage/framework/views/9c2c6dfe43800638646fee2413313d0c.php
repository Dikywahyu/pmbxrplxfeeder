<?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<a href="<?php echo e($notification->data['url']); ?>" class="py-6 px-7 d-flex align-items-center dropdown-item">
    <span class="me-3">
        <?php
        $imgUrl = $notification->data['image'] ?? 'user-1.jpg';
        if (!filter_var($imgUrl, FILTER_VALIDATE_URL)) {
        $imgUrl = asset($imgUrl);
        }
        ?>
        <img src="<?php echo e($imgUrl); ?>" alt="user" class="rounded-circle" width="48" height="48" />
    </span>
    <div class="w-100">
        <h6 class="mb-1 fw-semibold lh-base"><?php echo e($notification->data['title']); ?></h6>
        <span class="fs-2 d-block text-body-secondary"><?php echo e($notification->data['message']); ?></span>
        <small class="text-muted fs-1"><?php echo e($notification->created_at->diffForHumans()); ?></small>
    </div>
</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="py-6 px-7 text-center">
    <p class="mb-0 fs-2">Tidak ada notifikasi baru</p>
</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views/partials/notification-list.blade.php ENDPATH**/ ?>