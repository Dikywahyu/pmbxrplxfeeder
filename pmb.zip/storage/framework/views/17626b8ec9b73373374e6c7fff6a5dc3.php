<option value="">Pilih periode</option>
<?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($period->id); ?>"><?php echo e($period->nama_periode); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\period-options.blade.php ENDPATH**/ ?>