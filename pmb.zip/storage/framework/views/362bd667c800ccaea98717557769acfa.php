<?php $__env->startSection('title', 'Verifikasi Email - Integrated Academic Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="forny-form">
    <div class="mb-8 text-center forny-logo">
        <img src="https://cwcu.ac.id/theme/assets/img/logo.png">
    </div>
    
    <div class="text-center">
        <h4>Verifikasi Email Anda</h4>
        <p class="mb-10">Tautan verifikasi baru telah dikirim ke alamat email Anda.</p>
    </div>

    <?php if(session('resent')): ?>
        <div class="alert alert-success py-2 text-center">
            <small>Link verifikasi baru berhasil dikirim!</small>
        </div>
    <?php endif; ?>

    <div class="text-center">
        <p>Sebelum melanjutkan, silakan periksa email Anda untuk tautan verifikasi. Jika Anda tidak menerima email tersebut, silakan klik tombol di bawah untuk meminta tautan baru.</p>
    </div>

    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mt-6">
            <button type="submit" class="btn btn-primary btn-block">Kirim Ulang Verifikasi</button>
        </div>
    </form>

    <div class="text-center mt-8">
        <a href="<?php echo e(route('logout')); ?>" 
           onclick="event.preventDefault(); document.getElementById('logout-form').submit();" 
           class="text-muted">
            <small>Gunakan akun lain? Keluar</small>
        </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\auth\verify.blade.php ENDPATH**/ ?>