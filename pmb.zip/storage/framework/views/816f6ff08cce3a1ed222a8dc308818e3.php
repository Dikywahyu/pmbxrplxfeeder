<?php $__env->startSection('title', $attempt->exam->title); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="card border-primary shadow-sm sticky-top mb-4" style="top:10px;z-index:10"><div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-2"><div><h4 class="fw-bold mb-1"><?php echo e($attempt->exam->title); ?></h4><span class="text-muted"><?php echo e($attempt->exam->questions->count()); ?> soal · <?php echo e($attempt->exam->duration_minutes); ?> menit</span></div><div class="badge bg-danger fs-5 px-3 py-2">Sisa waktu: <span id="cbt-timer">--:--</span></div></div></div>
    <?php if($attempt->exam->description): ?><div class="alert alert-info"><?php echo e($attempt->exam->description); ?></div><?php endif; ?>
    <form id="cbt-answer-form" method="POST" enctype="multipart/form-data" action="<?php echo e(route('pmb.exams.submit', $attempt->id)); ?>"><?php echo csrf_field(); ?>
        <?php $__currentLoopData = $attempt->exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($saved = $attempt->answers->firstWhere('question_id', $question->id)); ?>
            <div class="card"><div class="card-body"><div class="d-flex justify-content-between"><h5 class="fw-semibold">Soal <?php echo e($index + 1); ?></h5><span class="badge bg-secondary-subtle text-secondary"><?php echo e($question->points); ?> poin</span></div>
                <p class="mb-3"><?php echo e($question->question_text); ?></p>
                <?php if($question->question_image_path): ?><img class="img-fluid rounded mb-3" style="max-height:360px" src="<?php echo e(asset('storage/'.$question->question_image_path)); ?>" alt="Gambar soal <?php echo e($index + 1); ?>"><?php endif; ?>
                <?php if($question->type === 'multiple_choice'): ?>
                    <?php $__currentLoopData = $question->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="d-flex align-items-start gap-2 border rounded p-3 mb-2 cursor-pointer"><input class="form-check-input mt-1" type="radio" name="answers[<?php echo e($question->id); ?>][selected_option]" value="<?php echo e($key); ?>" <?php if($saved?->selected_option === $key): echo 'checked'; endif; ?>><span><strong><?php echo e($key); ?>.</strong> <?php echo e($option['text'] ?? ''); ?> <?php if(!empty($option['image'])): ?><br><img src="<?php echo e(asset('storage/'.$option['image'])); ?>" alt="Gambar opsi <?php echo e($key); ?>" class="img-fluid rounded mt-2" style="max-height:220px"><?php endif; ?></span></label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <label class="form-label">Jawaban esai</label><textarea class="form-control mb-3" rows="6" name="answers[<?php echo e($question->id); ?>][answer_text]" maxlength="20000" placeholder="Tulis jawaban Anda"><?php echo e($saved?->answer_text); ?></textarea>
                    <label class="form-label">Lampiran gambar jawaban (opsional)</label><input class="form-control" type="file" name="answers[<?php echo e($question->id); ?>][answer_image]" accept="image/jpeg,image/png,image/webp"><small class="text-muted">Format JPG, PNG, atau WEBP; maksimal 5 MB.</small>
                    <?php if($saved?->answer_image_path): ?><div class="mt-2">Gambar terlampir sebelumnya: <a href="<?php echo e(asset('storage/'.$saved->answer_image_path)); ?>" target="_blank">Lihat</a></div><?php endif; ?>
                <?php endif; ?>
            </div></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex justify-content-end mb-5"><button class="btn btn-success btn-lg" onclick="return confirm('Kumpulkan jawaban sekarang? Ujian tidak dapat dibuka kembali setelah dikumpulkan.')"><i class="ti ti-send me-1"></i>Kumpulkan jawaban</button></div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
(() => {
    const deadline = new Date(<?php echo json_encode($deadline->toIso8601String(), 15, 512) ?>).getTime();
    const timer = document.getElementById('cbt-timer');
    const form = document.getElementById('cbt-answer-form');
    const tick = () => {
        const remaining = Math.max(0, Math.floor((deadline - Date.now()) / 1000));
        timer.textContent = `${String(Math.floor(remaining / 60)).padStart(2, '0')}:${String(remaining % 60).padStart(2, '0')}`;
        if (remaining <= 0) { timer.textContent = '00:00'; form.requestSubmit(); }
    };
    tick(); setInterval(tick, 1000);
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\pmb\exams\take.blade.php ENDPATH**/ ?>