<?php $__env->startSection('title', 'Soal CBT'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4"><div><h4 class="fw-semibold mb-1">Soal: <?php echo e($exam->title); ?></h4><p class="text-muted mb-0">Pilihan jawaban dapat berupa teks, gambar, atau gabungan keduanya.</p></div><a class="btn btn-light" href="<?php echo e(route('admin.cbt.index')); ?>">Kembali ke ujian</a></div>
    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <?php if($exam->is_published): ?><div class="alert alert-warning">Ujian sedang terbit. Tarik publikasi terlebih dahulu untuk mengubah soal.</div><?php else: ?>
    <div class="card"><div class="card-body"><h5 class="card-title">Tambah soal</h5>
        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.cbt.questions.store', $exam->id)); ?>" class="row g-3">
            <?php echo csrf_field(); ?>
            <div class="col-md-4"><label class="form-label">Jenis soal</label><select class="form-select" name="type" id="cbt-question-type"><option value="multiple_choice">Pilihan ganda</option><option value="essay">Esai</option></select></div>
            <div class="col-md-2"><label class="form-label">Poin</label><input class="form-control" name="points" type="number" min="1" max="1000" value="1" required></div>
            <div class="col-md-6"><label class="form-label">Gambar soal (opsional)</label><input class="form-control" name="question_image" type="file" accept="image/jpeg,image/png,image/webp"></div>
            <div class="col-12"><label class="form-label">Teks soal</label><textarea class="form-control" name="question_text" rows="3" required maxlength="20000"></textarea></div>
            <div class="col-12" id="cbt-options"><div class="row g-3">
                <?php $__currentLoopData = ['A','B','C','D','E']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6"><div class="border rounded p-3 h-100"><label class="form-label">Opsi <?php echo e($key); ?> <?php if($key==='A'): ?> <span class="text-danger">(jawaban benar?)</span><?php endif; ?></label><input class="form-control mb-2" name="option_text[<?php echo e($key); ?>]" placeholder="Teks opsi <?php echo e($key); ?>"><input class="form-control mb-2" type="file" name="option_image[<?php echo e($key); ?>]" accept="image/jpeg,image/png,image/webp"><div class="form-check"><input class="form-check-input" type="radio" name="correct_option" value="<?php echo e($key); ?>" <?php if($key==='A'): echo 'checked'; endif; ?>><label class="form-check-label">Tandai sebagai jawaban benar</label></div></div></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div></div>
            <div class="col-12"><button class="btn btn-primary">Tambah soal</button></div>
        </form>
    </div></div>
    <?php endif; ?>
    <div class="card"><div class="card-body"><h5 class="card-title">Daftar soal (<?php echo e($exam->questions->count()); ?>)</h5>
        <?php $__empty_1 = true; $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border rounded p-3 mb-3">
                <div class="d-flex justify-content-between gap-3"><div><span class="badge bg-primary-subtle text-primary me-2"><?php echo e($question->type === 'essay' ? 'Esai' : 'Pilihan ganda'); ?></span><span class="badge bg-secondary-subtle text-secondary"><?php echo e($question->points); ?> poin</span><p class="mt-2 mb-2"><?php echo e($question->question_text); ?></p>
                    <?php if($question->question_image_path): ?><img class="img-fluid rounded mb-2" style="max-height:220px" src="<?php echo e(asset('storage/'.$question->question_image_path)); ?>" alt="Gambar soal"><?php endif; ?>
                    <?php $__currentLoopData = $question->options ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div class="small mb-1"><strong><?php echo e($key); ?>.</strong> <?php echo e($option['text'] ?? ''); ?> <?php if(!empty($option['image'])): ?><img src="<?php echo e(asset('storage/'.$option['image'])); ?>" alt="Gambar opsi <?php echo e($key); ?>" style="max-height:70px" class="ms-2 rounded"><?php endif; ?> <?php if($question->correct_option===$key): ?><span class="badge bg-success ms-1">Benar</span><?php endif; ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if (! ($exam->is_published)): ?><form method="POST" action="<?php echo e(route('admin.cbt.questions.destroy', $question->id)); ?>" onsubmit="return confirm('Hapus soal ini?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Hapus</button></form><?php endif; ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="text-muted mb-0">Belum ada soal.</p><?php endif; ?>
    </div></div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>document.getElementById('cbt-question-type')?.addEventListener('change', e => { document.getElementById('cbt-options').classList.toggle('d-none', e.target.value !== 'multiple_choice'); });</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\cbt\questions.blade.php ENDPATH**/ ?>