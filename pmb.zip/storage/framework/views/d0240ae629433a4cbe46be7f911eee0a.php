<div class="preloader">
    <img src="https://cwcu.ac.id/theme/assets/img/logo2.png" alt="loader" class="lds-ripple img-fluid" />
</div><?php /**PATH C:\xampp\htdocs\pmb\resources\views/layouts/partials/preloader.blade.php ENDPATH**/ ?>