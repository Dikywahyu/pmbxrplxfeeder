<?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="border-top py-2">
        <strong><?php echo e($program->nama_prodi); ?></strong>
        <span class="text-muted">(<?php echo e($program->kode_prodi); ?> · <?php echo e($program->jenjang); ?>)</span>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-muted small mb-0">Belum ada program studi.</p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\programs.blade.php ENDPATH**/ ?>