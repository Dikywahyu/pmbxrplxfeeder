

<?php $__env->startSection('title', 'Persetujuan Akses SSO - Integrated Academic Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="forny-form">
    <div class="mb-8 text-center forny-logo">
        <img src="https://cwcu.ac.id/theme/assets/img/logo.png" alt="Logo Instansi">
    </div>
    
    <div class="text-center mb-6">
        <h4>Sign In SSO</h4>
        <p class="mb-4">
            Aplikasi <strong class="text-primary"><?php echo e($client->name); ?></strong> meminta izin resmi untuk mengakses profil akun Anda.
        </p>
    </div>

    <div class="alert alert-info border-0 py-2 px-3 mb-6 text-start" style="background-color: #e8f4fd; color: #1a73e8; border-radius: 6px; font-size: 0.85rem;">
        <small>ℹ️ Aplikasi ini akan membaca nama, email, foto profil, dan hak akses aktif Anda.</small>
    </div>

    <div class="d-flex flex-column gap-3">
        
        <form method="POST" action="<?php echo e(route('passport.authorizations.approve')); ?>" class="w-100 m-0">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="state" value="<?php echo e($request->state); ?>">
            <input type="hidden" name="client_id" value="<?php echo e($client->id); ?>">
            <input type="hidden" name="auth_token" value="<?php echo e($authToken); ?>">
            <button type="submit" class="btn btn-outline-success py-2.5 fw-semibold w-100 m-2" style="letter-spacing: 0.3px;">
                ✔️ Izinkan Akses
            </button>
        </form>

        <form method="POST" action="<?php echo e(route('passport.authorizations.deny')); ?>" class="w-100 m-0">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="hidden" name="state" value="<?php echo e($request->state); ?>">
            <input type="hidden" name="client_id" value="<?php echo e($client->id); ?>">
            <input type="hidden" name="auth_token" value="<?php echo e($authToken); ?>">
            <button type="submit" class="btn btn-outline-danger py-2.5 fw-semibold w-100  m-2" style="letter-spacing: 0.3px;">
                ❌ Tolak & Batalkan
            </button>
        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\passport\authorize.blade.php ENDPATH**/ ?>