<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#d71920">
    <title><?php echo $__env->yieldContent('title', 'Penerimaan Mahasiswa Baru'); ?> · PMB</title>
    <link rel="shortcut icon" type="image/png" href="https://cwcu.ac.id/theme/assets/img/logo2.png">
    <link rel="stylesheet" href="<?php echo e(asset('dist/assets/css/styles.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views/layouts/pmb-public.blade.php ENDPATH**/ ?>