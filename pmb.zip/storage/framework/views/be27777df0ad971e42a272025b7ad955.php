<?php $__env->startSection('title', 'Klaim Akun PMB'); ?>

<?php $__env->startSection('content'); ?>
<div class="forny-form">
    <div class="text-center mb-4">
        <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-primary-subtle text-primary mb-3" style="width:64px;height:64px;font-size:1.8rem"><i class="ti ti-user-check"></i></div>
        <h4 class="mb-2">Klaim akun PMB</h4>
        <?php if(isset($candidate)): ?>
            <p class="text-muted mb-0">Pendaftaran untuk <strong><?php echo e($candidate->nama_mahasiswa); ?></strong></p>
        <?php else: ?>
            <p class="text-muted mb-0">Hubungkan akun Anda ke pendaftaran mahasiswa.</p>
        <?php endif; ?>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>

    <?php if($state === 'expired'): ?>
        <div class="alert alert-warning">Link klaim ini sudah kedaluwarsa. Hubungi marketing yang mendaftarkan Anda untuk meminta link baru.</div>
    <?php elseif($state === 'nik_missing'): ?>
        <div class="alert alert-warning">NIK belum tercatat pada pendaftaran ini. Hubungi marketing agar data NIK diperbarui sebelum klaim.</div>
    <?php elseif($state === 'claimed'): ?>
        <div class="alert alert-info">Pendaftaran ini sudah diklaim. Jika ini pendaftaran Anda, masuklah menggunakan akun mahasiswa Anda.</div>
        <a class="btn btn-primary w-100" href="<?php echo e(route('login')); ?>">Masuk ke akun</a>
    <?php elseif($state === 'ready'): ?>
        <p class="text-muted text-center">Masukkan NIK pendaftaran untuk menghubungkan pendaftaran dengan akun <strong><?php echo e(auth()->user()->email); ?></strong>.</p>
        <form method="POST" action="<?php echo e(route('pmb.claim.store', ['token' => request()->route('token')])); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-4"><label class="form-label" for="claim-nik">NIK mahasiswa</label><input class="form-control" id="claim-nik" type="text" name="nik" inputmode="numeric" maxlength="16" minlength="16" autocomplete="off" required></div>
            <button class="btn btn-primary w-100 py-2" type="submit">Klaim pendaftaran</button>
        </form>
    <?php else: ?>
        <p class="text-muted text-center">Gunakan NIK yang didaftarkan marketing. Masukkan email yang akan Anda gunakan untuk akun PMB, lalu buat kata sandi.</p>
        <form method="POST" action="<?php echo e(route('pmb.claim.store', ['token' => request()->route('token')])); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3"><label class="form-label" for="claim-nik">NIK mahasiswa</label><input class="form-control" id="claim-nik" type="text" name="nik" inputmode="numeric" maxlength="16" minlength="16" autocomplete="off" required></div>
            <div class="mb-3"><label class="form-label" for="claim-email">Email akun yang akan digunakan</label><input class="form-control" id="claim-email" type="email" name="email" maxlength="255" autocomplete="email" required></div>
            <div class="mb-3"><label class="form-label" for="claim-password">Kata sandi baru</label><input class="form-control" id="claim-password" type="password" name="password" minlength="8" autocomplete="new-password" required></div>
            <div class="mb-4"><label class="form-label" for="claim-password-confirmation">Ulangi kata sandi</label><input class="form-control" id="claim-password-confirmation" type="password" name="password_confirmation" minlength="8" autocomplete="new-password" required></div>
            <button class="btn btn-primary w-100 py-2" type="submit">Buat akun dan klaim</button>
        </form>
    <?php endif; ?>

    <div class="text-center mt-4"><a class="small text-muted" href="<?php echo e(route('login')); ?>">Kembali ke halaman masuk</a></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\pmb\claim.blade.php ENDPATH**/ ?>