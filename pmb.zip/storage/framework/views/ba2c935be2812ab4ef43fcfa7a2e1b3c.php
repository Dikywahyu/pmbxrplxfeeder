<option value="">Pilih jalur</option>
<?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($path->id); ?>"><?php echo e($path->nama_jalur); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\path-options.blade.php ENDPATH**/ ?>