<option value="">Pilih program studi</option>
<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($program->id); ?>"><?php echo e($program->nama_prodi); ?> (<?php echo e($program->jenjang); ?>)</option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\program-options.blade.php ENDPATH**/ ?>