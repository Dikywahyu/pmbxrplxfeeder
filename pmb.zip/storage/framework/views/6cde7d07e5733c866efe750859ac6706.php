<?php $__env->startSection('title', 'Hasil Ujian'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-3"><div class="card"><div class="card-body text-center py-5"><i class="ti ti-circle-check fs-1 text-success"></i><h3 class="fw-bold mt-2">Jawaban berhasil dikumpulkan</h3><h5><?php echo e($attempt->exam->title); ?></h5>
    <?php ($pendingEssay = $attempt->answers->filter(fn($answer) => $answer->question->type === 'essay' && $answer->score === null)->count()); ?>
    <div class="display-6 fw-bold text-primary mt-3"><?php echo e($attempt->score); ?></div><p class="text-muted">Nilai sementara</p>
    <?php if($pendingEssay): ?><div class="alert alert-info d-inline-block"><?php echo e($pendingEssay); ?> jawaban esai menunggu penilaian panitia. Nilai akhir diperbarui setelah pemeriksaan.</div><?php else: ?><div class="alert alert-success d-inline-block">Semua jawaban sudah dinilai.</div><?php endif; ?>
    <div><a href="<?php echo e(route('pmb.exams.index')); ?>" class="btn btn-primary">Kembali ke daftar ujian</a></div>
</div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\pmb\exams\result.blade.php ENDPATH**/ ?>