<?php $__empty_1 = true; $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="d-flex justify-content-between align-items-center border-top py-2 gap-2">
        <span class="small">
            <?php echo e($period->nama_periode); ?>

            <span class="badge <?php echo e($period->is_active ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($period->is_active ? 'Aktif' : 'Nonaktif'); ?></span>
            <span class="text-muted"><?php echo e($period->tanggal_mulai->format('d/m/Y')); ?> – <?php echo e($period->tanggal_selesai->format('d/m/Y')); ?></span>
        </span>
        <form method="POST" action="<?php echo e(route('admin.pmb.periods.status', $period->id)); ?>" data-ajax-form>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <input type="hidden" name="is_active" value="<?php echo e($period->is_active ? 0 : 1); ?>">
            <button class="btn btn-outline-secondary btn-sm" type="submit"><?php echo e($period->is_active ? 'Tutup' : 'Aktifkan'); ?></button>
        </form>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="text-muted small mb-0">Belum ada periode.</p>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\periods.blade.php ENDPATH**/ ?>