

<?php $__env->startSection('title', 'Presensi Kehadiran - ' . $session->activity->title); ?>

<?php $__env->startPush('styles'); ?>
<style>
    html, body {
        height: auto !important;
        overflow-y: auto !important;
    }
    body {
        min-height: 100vh !important;
        display: block !important;
        background-color: #f4f6f9;
    }
    .forny-container {
        min-height: 100vh !important;
        height: auto !important;
        display: block !important;
        padding: 30px 15px 120px 15px !important;
    }
    .forny-inner {
        margin: 0 auto !important;
        max-width: 520px !important;
    }
    .countdown-box {
        background: #f8f9fa;
        border: 2px dashed #0d6efd;
        border-radius: 12px;
        padding: 15px;
    }
    .timer-number {
        font-size: 1.8rem;
        font-weight: 700;
        color: #0d6efd;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="forny-form">
    
    <div class="mb-4 text-center forny-logo">
        <img src="https://cwcu.ac.id/theme/assets/img/logo.png" alt="Logo" style="max-height: 60px;">
    </div>
    
    
    <div class="text-center mb-4">
        <span class="badge badge-info mb-2 py-1 px-3">
            <?php echo e($session->activity->activityType->name ?? 'Kegiatan'); ?>

        </span>
        <h4 class="mb-1 text-dark fw-bold"><?php echo e($session->activity->title); ?></h4>
        <p class="text-muted small mb-0">
            <strong>Sesi:</strong> <?php echo e($session->session_name); ?>

        </p>
        <small class="text-muted d-block mt-1">
            📍 <?php echo e($session->activity->location ?? 'Ruangan Utama'); ?> | 
            ⏰ <?php echo e(\Carbon\Carbon::parse($session->start_time)->timezone('Asia/Jakarta')->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($session->end_time)->timezone('Asia/Jakarta')->format('H:i')); ?> WIB
        </small>
    </div>

    
    <?php if(session('error') || isset($error)): ?>
        <div class="alert alert-danger py-2 mb-4 text-center small">
            <?php echo e(session('error') ?? $error); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success py-3 mb-4 text-center">
            <strong>Berhasil!</strong><br>
            <small><?php echo e(session('success')); ?></small>
        </div>
    <?php else: ?>

        <?php
            // Timestamp Unix dalam Milidetik untuk JavaScript Countdown
            $nowTimestamp   = \Carbon\Carbon::now('Asia/Jakarta')->timestamp * 1000;
            $startTimestamp = \Carbon\Carbon::parse($session->start_time)->timezone('Asia/Jakarta')->timestamp * 1000;
            $endTimestamp   = \Carbon\Carbon::parse($session->end_time)->timezone('Asia/Jakarta')->timestamp * 1000;

            $isNotStarted = $nowTimestamp < $startTimestamp;
            $isExpired    = $nowTimestamp > $endTimestamp;
        ?>

        
        <?php if($isNotStarted): ?>
            <div class="card border-0 shadow-sm text-center p-4 my-3">
                <div class="mb-2">
                    <span class="badge bg-warning text-dark px-3 py-1">⚠️ PRESENSI BELUM DIBUKA</span>
                </div>
                <p class="text-muted small mb-3">
                    Formulir presensi akan otomatis terbuka pada jam 
                    <strong><?php echo e(\Carbon\Carbon::parse($session->start_time)->timezone('Asia/Jakarta')->format('d M Y, H:i')); ?> WIB</strong>
                </p>

                
                <div class="countdown-box my-2">
                    <small class="text-muted d-block mb-1 font-weight-bold">Waktu Mundur Pembukaan:</small>
                    <div id="countdown-timer" class="timer-number">00:00:00</div>
                </div>
                
                <small class="text-muted mt-2 d-block style="font-size: 11px;">Halaman ini akan otomatis memuat ulang saat waktu tiba.</small>
            </div>

            <script>
                document.addEventListener("DOMContentLoaded", function () {
                    const startTime = <?php echo e($startTimestamp); ?>;

                    function updateCountdown() {
                        const now = new Date().getTime();
                        const distance = startTime - now;

                        if (distance <= 0) {
                            document.getElementById("countdown-timer").innerHTML = "00:00:00";
                            // Reload otomatis begitu waktu tiba
                            location.reload();
                            return;
                        }

                        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                        const h = hours < 10 ? "0" + hours : hours;
                        const m = minutes < 10 ? "0" + minutes : minutes;
                        const s = seconds < 10 ? "0" + seconds : seconds;

                        document.getElementById("countdown-timer").innerHTML = `${h}:${m}:${s}`;
                    }

                    updateCountdown();
                    setInterval(updateCountdown, 1000);
                });
            </script>

        
        <?php elseif($isExpired): ?>
            <div class="card border-0 shadow-sm text-center p-4 my-3 bg-light">
                <div class="mb-2">
                    <span class="badge bg-danger text-white px-3 py-1">🚫 PRESENSI TELAH DITUTUP</span>
                </div>
                <p class="text-muted small mb-0">
                    Batas waktu presensi untuk sesi ini telah berakhir pada pukul 
                    <strong><?php echo e(\Carbon\Carbon::parse($session->end_time)->timezone('Asia/Jakarta')->format('H:i')); ?> WIB</strong>.
                </p>
            </div>

        
        <?php else: ?>

            <form action="<?php echo e(route('attendances.public_submit', $session->qr_code_token)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <?php if(auth()->guard()->check()): ?>
                    <div class="alert alert-info py-2 px-3 mb-4 text-center small">
                        Terdeteksi akun: <strong><?php echo e(auth()->user()->email); ?></strong>. Silakan sesuaikan data presensi Anda jika diperlukan.
                    </div>
                <?php endif; ?>

                <?php
                    $defaultName     = old('guest_name', auth()->user()->name ?? '');
                    $defaultEmail    = old('guest_email', auth()->user()->email ?? '');
                    $defaultPhone    = old('guest_phone', auth()->user()->phone ?? '');
                    $defaultGender   = old('guest_gender', auth()->user()->gender ?? '');
                    $defaultPosition = old('guest_position', auth()->user()->position_title ?? '');
                    $defaultInst     = old('guest_organization', auth()->user()->institution ?? '');
                ?>

                <div class="form-group mb-3">
                    <label class="form-label small text-muted mb-1">Nama Lengkap & Gelar <span class="text-danger">*</span></label>
                    <input required class="form-control" name="guest_name" type="text" placeholder="Masukkan nama lengkap" value="<?php echo e($defaultName); ?>">
                </div>

                <div class="row">
                    <div class="col-md-6 form-group mb-3">
                        <label class="form-label small text-muted mb-1">Email <span class="text-danger">*</span></label>
                        <input required class="form-control" name="guest_email" type="email" placeholder="contoh@email.com" value="<?php echo e($defaultEmail); ?>">
                    </div>
                    <div class="col-md-6 form-group mb-3">
                        <label class="form-label small text-muted mb-1">No. WhatsApp / HP <span class="text-danger">*</span></label>
                        <input required class="form-control" name="guest_phone" type="text" placeholder="081234567xxx" value="<?php echo e($defaultPhone); ?>">
                    </div>
                </div>

                <div class="form-group mb-3">
                    <label class="form-label small text-muted mb-1">Jenis Kelamin <span class="text-danger">*</span></label>
                    <div class="d-flex gap-3 mt-1">
                        <div class="custom-control custom-radio mr-4">
                            <input type="radio" id="gender_l" name="guest_gender" value="L" class="custom-control-input" required <?php echo e($defaultGender == 'L' ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="gender_l">Laki-laki</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input type="radio" id="gender_p" name="guest_gender" value="P" class="custom-control-input" required <?php echo e($defaultGender == 'P' ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="gender_p">Perempuan</label>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 form-group mb-3">
                        <label class="form-label small text-muted mb-1">Jabatan / Status</label>
                        <input class="form-control" name="guest_position" type="text" placeholder="Contoh: Dosen / Staff / Peserta" value="<?php echo e($defaultPosition); ?>">
                    </div>
                    <div class="col-md-6 form-group mb-3">
                        <label class="form-label small text-muted mb-1">Instansi / Organisasi</label>
                        <input class="form-control" name="guest_organization" type="text" placeholder="Contoh: Universitas X / PT Y" value="<?php echo e($defaultInst); ?>">
                    </div>
                </div>

                <div class="mt-4 mb-5 pb-4">
                    <button type="submit" class="btn btn-primary btn-block py-2 w-100 shadow-sm">
                        Kirim Presensi Kehadiran
                    </button>
                </div>

            </form>

        <?php endif; ?>

    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\apps\activities\public_form.blade.php ENDPATH**/ ?>