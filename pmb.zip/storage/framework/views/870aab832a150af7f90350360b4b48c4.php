<?php $__empty_1 = true; $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($fee->period?->nama_periode ?? 'Periode tidak tersedia'); ?></td>
        <td><?php echo e($fee->path?->nama_jalur ?? 'Jalur tidak tersedia'); ?></td>
        <td><?php echo e($fee->program?->nama_prodi ?? 'Prodi tidak tersedia'); ?></td>
        <td>Rp <?php echo e(number_format($fee->nominal_pendaftaran, 0, ',', '.')); ?></td>
        <td>Rp <?php echo e(number_format($fee->nominal_spp, 0, ',', '.')); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5" class="text-center text-muted">Belum ada pengaturan biaya.</td></tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\partials\fees.blade.php ENDPATH**/ ?>