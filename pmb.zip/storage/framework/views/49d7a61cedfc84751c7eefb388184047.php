<?php $__env->startSection('title', 'Ujian CBT'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-3"><div class="mb-4"><h3 class="fw-bold mb-1">Ujian CBT</h3><p class="text-muted mb-0">Ujian dapat berisi pilihan ganda dan esai. Perhatikan jadwal dan durasi sebelum memulai.</p></div>
    <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php ($attempt = $attempts->get($exam->id)); ?>
        <div class="card shadow-sm"><div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div><h5 class="fw-semibold mb-1"><?php echo e($exam->title); ?></h5><p class="text-muted mb-2"><?php echo e($exam->description); ?></p><span class="badge bg-primary-subtle text-primary"><?php echo e($exam->questions_count); ?> soal</span><span class="badge bg-secondary-subtle text-secondary"><?php echo e($exam->duration_minutes); ?> menit</span>
                <?php if($exam->starts_at): ?><span class="badge bg-light text-dark">Mulai <?php echo e($exam->starts_at->format('d/m/Y H:i')); ?></span><?php endif; ?> <?php if($exam->ends_at): ?><span class="badge bg-light text-dark">Tutup <?php echo e($exam->ends_at->format('d/m/Y H:i')); ?></span><?php endif; ?>
            </div>
            <div>
                <?php if($attempt?->status === 'submitted'): ?><a class="btn btn-outline-primary" href="<?php echo e(route('pmb.exams.result', $attempt->id)); ?>">Lihat hasil</a>
                <?php elseif($attempt?->status === 'in_progress'): ?><a class="btn btn-warning" href="<?php echo e(route('pmb.exams.take', $attempt->id)); ?>">Lanjutkan ujian</a>
                <?php elseif($registrations->isNotEmpty()): ?><form method="POST" action="<?php echo e(route('pmb.exams.start', [$exam->id, $registrations->first()->id])); ?>"><?php echo csrf_field(); ?><button class="btn btn-primary">Mulai ujian</button></form>
                <?php else: ?><span class="text-muted">Anda perlu memiliki pendaftaran PMB untuk mengikuti ujian.</span><?php endif; ?>
            </div>
        </div></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><div class="card"><div class="card-body text-center py-5"><i class="ti ti-clipboard-off fs-1 text-muted"></i><h5 class="mt-2">Belum ada ujian tersedia</h5><p class="text-muted mb-0">Ujian akan muncul di sini saat panitia menerbitkannya.</p></div></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pmb\resources\views\pmb\exams\index.blade.php ENDPATH**/ ?>