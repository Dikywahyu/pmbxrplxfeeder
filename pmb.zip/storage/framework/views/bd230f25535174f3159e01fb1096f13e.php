<?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td data-label="Pendaftar">
            <strong><?php echo e($registration->candidate?->nama_mahasiswa); ?></strong><br>
            <small><?php echo e($registration->nomor_pendaftaran); ?></small><br>
            <small class="text-muted">
                <?php echo e($registration->candidate?->user?->email ?? $registration->candidate?->email ?? 'Email tidak tersedia'); ?>

                · <?php echo e($registration->candidate?->handphone ?: 'Nomor HP belum diisi'); ?>

            </small>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pmb-registration-manage')): ?>
                <form method="POST" action="<?php echo e(route('admin.pmb.registrations.desil', $registration->id)); ?>" data-registration-desil-form class="mt-2">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <select class="form-select form-select-sm pmb-desil-select" name="desil" data-registration-desil data-current-desil="<?php echo e($registration->candidate?->desil ?? ''); ?>" aria-label="Kategori desil mahasiswa">
                        <option value="" <?php if(empty($registration->candidate?->desil)): echo 'selected'; endif; ?>>Pilih desil</option>
                        <?php for($desil = 1; $desil <= 10; $desil++): ?>
                            <option value="<?php echo e($desil); ?>" <?php if((int) ($registration->candidate?->desil ?? 0) === $desil): echo 'selected'; endif; ?>>Desil <?php echo e($desil); ?></option>
                        <?php endfor; ?>
                    </select>
                </form>
            <?php else: ?>
                <br><span class="badge <?php echo e($registration->candidate?->desil ? 'bg-info-subtle text-info' : 'bg-light text-muted'); ?> mt-1"><?php echo e($registration->candidate?->desil ? 'Desil '.$registration->candidate->desil : 'Desil belum ditentukan'); ?></span>
            <?php endif; ?>
        </td>
        <td data-label="Periode / Jalur / Prodi">
            <?php echo e($registration->period?->nama_periode ?? 'Periode tidak tersedia'); ?><br>
            <small>
                <?php echo e($registration->path?->nama_jalur ?? 'Jalur tidak tersedia'); ?> ·
                <?php echo e($registration->program1?->nama_prodi ?? 'Program studi tidak tersedia'); ?>

            </small>
            <?php if($registration->nominal_spp !== null): ?>
                <br><small class="text-primary fw-semibold">SPP/semester: Rp <?php echo e(number_format((float) $registration->nominal_spp, 0, ',', '.')); ?></small>
            <?php endif; ?>
        </td>
        <td data-label="Status seleksi">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pmb-review')): ?>
                <form method="POST" action="<?php echo e(route('admin.pmb.registrations.status', $registration->id)); ?>" data-registration-status-form>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <select class="form-select form-select-sm pmb-status-select" name="status" aria-label="Status seleksi" data-current-status="<?php echo e($registration->status); ?>">
                        <?php $__currentLoopData = ['berkas_masuk' => 'Berkas masuk', 'review' => 'Dalam review', 'sudah_ujian' => 'Sudah ujian', 'lulus' => 'Lulus', 'diterima' => 'Diterima', 'ditolak' => 'Ditolak', 'mundur' => 'Mundur']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php if($registration->status === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            <?php else: ?>
                <span class="badge bg-primary-subtle text-primary"><?php echo e(str_replace('_', ' ', ucfirst($registration->status))); ?></span>
            <?php endif; ?>
        </td>
        <td data-label="Berkas">
            <div class="pmb-registration-documents">
            <?php $__empty_1 = true; $__currentLoopData = $registration->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $documentStatusLabel = ['pending' => 'Menunggu', 'valid' => 'Disetujui', 'invalid' => 'Perbaikan'][$document->status_verifikasi] ?? ucfirst($document->status_verifikasi);
                    $documentName = $document->requirement?->nama_dokumen ?? 'Berkas';
                    $normalizedDocumentName = mb_strtolower($documentName);
                    $documentKind = 'default';

                    if (str_contains($normalizedDocumentName, 'ktp')) {
                        $documentKind = 'identity';
                    } elseif (str_contains($normalizedDocumentName, 'keluarga')) {
                        $documentKind = 'family';
                    } elseif (str_contains($normalizedDocumentName, 'sktm')) {
                        $documentKind = 'poverty';
                    } elseif (str_contains($normalizedDocumentName, 'ijazah')) {
                        $documentKind = 'diploma';
                    } elseif (str_contains($normalizedDocumentName, 'kip')) {
                        $documentKind = 'kip';
                    } elseif (str_contains($normalizedDocumentName, 'pip') || str_contains($normalizedDocumentName, 'pkh')) {
                        $documentKind = 'aid';
                    }
                ?>
                <button type="button" class="pmb-document-chip" data-kind="<?php echo e($documentKind); ?>" data-status="<?php echo e($document->status_verifikasi); ?>" data-document-review data-document-name="<?php echo e($documentName); ?>" data-document-status="<?php echo e($documentStatusLabel); ?>" data-document-url="<?php echo e(route('pmb.documents.download', $document->id)); ?>" data-document-preview-url="<?php echo e(route('pmb.documents.preview', $document->id)); ?>" data-document-extension="<?php echo e(strtolower(pathinfo($document->file_path, PATHINFO_EXTENSION))); ?>" data-review-url="<?php echo e(route('admin.pmb.documents.verify', $document->id)); ?>" title="Klik untuk membuka dan meninjau berkas">
                    <i class="ti ti-file-text" aria-hidden="true"></i><span><?php echo e($document->requirement?->nama_dokumen ?? 'Berkas'); ?></span><small><?php echo e($documentStatusLabel); ?></small><i class="ti ti-chevron-right pmb-document-chevron" aria-hidden="true"></i>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <small class="text-muted">Belum diunggah</small>
            <?php endif; ?>
            </div>
        </td>
        <td data-label="Pembayaran">
            <?php $__empty_1 = true; $__currentLoopData = $registration->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-3">
                    <strong><?php echo e(ucfirst(str_replace('_', ' ', $payment->jenis_tagihan))); ?>: Rp <?php echo e(number_format($payment->nominal_tagihan, 0, ',', '.')); ?></strong><br>
                    <span class="badge bg-secondary-subtle text-secondary"><?php echo e(str_replace('_', ' ', ucfirst($payment->status))); ?></span>
                    <?php if($payment->file_bukti_bayar): ?>
                        <div class="mt-2"><a href="<?php echo e(route('pmb.payments.download', $payment->id)); ?>">Unduh bukti bayar</a></div>
                    <?php endif; ?>
                    <?php if($payment->status === 'menunggu_verifikasi'): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pmb-payment-review')): ?>
                            <div class="d-flex gap-1 mt-2">
                                <?php $__currentLoopData = ['lunas' => 'Setujui', 'ditolak' => 'Tolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form method="POST" action="<?php echo e(route('admin.pmb.payments.verify', $payment->id)); ?>" data-ajax-form>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="status" value="<?php echo e($status); ?>">
                                        <button class="btn <?php echo e($status === 'lunas' ? 'btn-success' : 'btn-outline-danger'); ?> btn-sm" type="submit"><?php echo e($label); ?></button>
                                    </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span class="text-muted">Belum ada tagihan</span>
            <?php endif; ?>
        </td>
        <td class="text-nowrap" data-label="Aksi">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pmb-registration-manage')): ?>
                <button type="button" class="btn btn-sm btn-light-primary text-primary" data-pmb-edit data-update-url="<?php echo e(route('admin.pmb.registrations.update', $registration->id)); ?>" data-payload="<?php echo e(json_encode(['record' => ['nama_mahasiswa' => $registration->candidate?->nama_mahasiswa, 'nik' => $registration->candidate?->nik, 'jenis_kelamin' => $registration->candidate?->jenis_kelamin, 'handphone' => $registration->candidate?->handphone, 'desil' => $registration->candidate?->desil, 'status' => $registration->status]])); ?>"><i class="ti ti-edit"></i> Edit</button>
                <button type="button" class="btn btn-sm btn-light-danger text-danger" data-pmb-delete data-delete-url="<?php echo e(route('admin.pmb.registrations.destroy', $registration->id)); ?>"><i class="ti ti-trash"></i> Hapus</button>
            <?php else: ?>
                <span class="text-muted">—</span>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views/admin/pmb/partials/registrations.blade.php ENDPATH**/ ?>