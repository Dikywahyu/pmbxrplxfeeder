<div class="alert alert-info border-0 shadow-sm mb-3">
    <i class="ti ti-info-circle me-1"></i> Kelola akun marketing, link referral, dan harga SPP khusus dalam satu halaman.
</div>

<ul class="nav nav-pills pmb-fee-tabs gap-2 mb-4" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="pmb-referrals-marketing-tab" data-bs-toggle="pill" data-bs-target="#pmb-referrals-marketing-pane" type="button" role="tab" aria-controls="pmb-referrals-marketing-pane" aria-selected="true">
            <i class="ti ti-users me-1"></i>Marketing & Referral <span class="badge rounded-pill bg-white text-primary ms-1"><?php echo e($referrals->count()); ?></span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="pmb-referrals-spp-tab" data-bs-toggle="pill" data-bs-target="#pmb-referrals-spp-pane" type="button" role="tab" aria-controls="pmb-referrals-spp-pane" aria-selected="false">
            <i class="ti ti-currency-rupiah me-1"></i>Harga SPP <span class="badge rounded-pill bg-white text-primary ms-1"><?php echo e($sppRates->count()); ?></span>
        </button>
    </li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade show active" id="pmb-referrals-marketing-pane" role="tabpanel" aria-labelledby="pmb-referrals-marketing-tab">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-primary-subtle border-0"><h5 class="card-title mb-1">Tambah marketing</h5><small class="text-muted">Tautkan akun pengguna ke kode referral. Pendaftar dari link tersebut akan tercatat pada akun marketing.</small></div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.pmb.referrals.store')); ?>" method="POST" data-ajax-form class="row g-3 align-items-end">
                    <?php echo csrf_field(); ?>
                    <div class="col-12 col-lg-8">
                        <label class="form-label" for="referral-owner">Akun pengguna</label>
                        <select class="form-select" id="referral-owner" name="owner_id" required>
                            <option value="">Pilih akun</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if (! ($referrals->contains('owner_id', $user->id))): ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> — <?php echo e($user->email); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-12 col-lg-4"><button class="btn btn-primary w-100" type="submit"><i class="ti ti-user-plus me-1"></i>Buat kode referral</button></div>
                </form>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0"><h5 class="card-title mb-1">Daftar marketing</h5><small class="text-muted">Salin link referral atau ubah status akun marketing.</small></div>
            <div class="card-body">
                <div class="table-responsive"><table class="table table-hover align-middle pmb-data-table w-100">
                    <thead class="table-light"><tr><th>Marketing</th><th>Email</th><th>Kode referral</th><th>Link referral</th><th>Pendaftar</th><th>Status</th><th data-orderable="false" data-searchable="false">Aksi</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($link = route('pmb.index', ['ref' => $referral->kode_referral])); ?>
                            <tr>
                                <td class="fw-semibold"><?php echo e($referral->owner?->name ?? 'Akun dihapus'); ?></td>
                                <td><?php echo e($referral->owner?->email ?? '—'); ?></td>
                                <td><code><?php echo e($referral->kode_referral); ?></code></td>
                                <td><button type="button" class="btn btn-sm btn-light-primary text-primary" data-copy-link="<?php echo e($link); ?>"><i class="ti ti-copy me-1"></i>Salin link</button></td>
                                <td><span class="badge bg-primary-subtle text-primary"><?php echo e($referral->registrations_count); ?></span></td>
                                <td><span class="badge <?php echo e($referral->is_active ? 'bg-success-subtle text-success' : 'bg-secondary-subtle text-secondary'); ?>"><?php echo e($referral->is_active ? 'Aktif' : 'Nonaktif'); ?></span></td>
                                <td class="text-nowrap">
                                    <form action="<?php echo e(route('admin.pmb.referrals.status', $referral->id)); ?>" method="POST" data-ajax-form class="d-inline">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="is_active" value="<?php echo e($referral->is_active ? 0 : 1); ?>">
                                        <button class="btn btn-sm btn-outline-primary" type="submit"><?php echo e($referral->is_active ? 'Nonaktifkan' : 'Aktifkan'); ?></button>
                                    </form>
                                    <button type="button" class="btn btn-sm btn-outline-danger" data-pmb-delete data-delete-url="<?php echo e(route('admin.pmb.referrals.destroy', $referral->id)); ?>">Hapus</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table></div>
                <?php if($referrals->isEmpty()): ?><div class="text-center text-muted py-3">Belum ada marketing. Tambahkan akun di atas untuk membuat kode referral.</div><?php endif; ?>
            </div>
        </div>
    </div>

    <div class="tab-pane fade" id="pmb-referrals-spp-pane" role="tabpanel" aria-labelledby="pmb-referrals-spp-tab">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-primary-subtle border-0"><h5 class="card-title mb-1"><i class="ti ti-currency-rupiah me-2 text-primary"></i>Atur harga SPP massal</h5><small class="text-muted">Harga akan diterapkan ke semua program studi pada periode dan jalur yang dipilih untuk marketing tersebut.</small></div>
            <div class="card-body">
                <form action="<?php echo e(route('admin.pmb.referrals.spp-rates.bulk')); ?>" method="POST" data-ajax-form class="row g-3 align-items-end">
                    <?php echo csrf_field(); ?>
                    <div class="col-12 col-md-6 col-xl-3"><label class="form-label" for="spp-bulk-referral">Marketing</label><select class="form-select" id="spp-bulk-referral" name="referral_id" required><option value="">Pilih marketing</option><?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $referral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($referral->id); ?>"><?php echo e($referral->owner?->name); ?> (<?php echo e($referral->kode_referral); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="col-12 col-md-6 col-xl-3"><label class="form-label" for="spp-bulk-period">Periode</label><select class="form-select" id="spp-bulk-period" name="period_id" required><option value="">Pilih periode</option><?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($period->id); ?>"><?php echo e($period->nama_periode); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="col-12 col-md-6 col-xl-3"><label class="form-label" for="spp-bulk-path">Jalur</label><select class="form-select" id="spp-bulk-path" name="path_id" required><option value="">Pilih jalur</option><?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($path->id); ?>"><?php echo e($path->nama_jalur); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="col-8 col-md-4 col-xl-2"><label class="form-label" for="spp-bulk-amount">Harga SPP (Rp)</label><input class="form-control" id="spp-bulk-amount" type="number" name="nominal_spp" min="0" step="1000" required></div>
                    <div class="col-12 col-md-6 col-xl-1"><button class="btn btn-primary w-100" type="submit" title="Terapkan ke semua program studi"><i class="ti ti-device-floppy me-1"></i>Terapkan</button></div>
                    <div class="col-12"><small class="text-muted">Harga massal memperbarui semua prodi yang sudah memiliki konfigurasi biaya untuk kombinasi periode dan jalur tersebut.</small></div>
                </form>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0"><h5 class="card-title mb-1">Daftar harga khusus marketing</h5><small class="text-muted">Gunakan tombol Ubah pada baris untuk mengedit satu kombinasi harga melalui modal.</small></div>
            <div class="card-body">
                <div class="table-responsive"><table class="table table-hover align-middle pmb-data-table w-100">
                    <thead class="table-light"><tr><th>Marketing</th><th>Periode</th><th>Jalur</th><th>Program studi</th><th>SPP standar</th><th>SPP khusus</th><th data-orderable="false" data-searchable="false">Aksi</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $sppRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($rate->referral?->owner?->name); ?> <small class="text-muted d-block"><?php echo e($rate->referral?->kode_referral); ?></small></td>
                                <td><?php echo e($rate->fee?->period?->nama_periode); ?></td><td><?php echo e($rate->fee?->path?->nama_jalur); ?></td><td><?php echo e($rate->fee?->program?->nama_prodi); ?></td>
                                <td>Rp <?php echo e(number_format((float) ($rate->fee?->nominal_spp ?? 0), 0, ',', '.')); ?></td>
                                <td><span class="badge rounded-pill bg-success-subtle text-success">Rp <?php echo e(number_format((float) $rate->nominal_spp, 0, ',', '.')); ?></span></td>
                                <td class="text-nowrap"><button type="button" class="btn btn-sm btn-light-primary text-primary" data-pmb-edit data-edit-schema="referralSppRate" data-update-url="<?php echo e(route('admin.pmb.referrals.spp-rates.update', $rate->id)); ?>" data-payload="<?php echo e(json_encode(['record' => ['nominal_spp' => $rate->nominal_spp]])); ?>"><i class="ti ti-edit"></i> Ubah</button> <button type="button" class="btn btn-sm btn-light-danger text-danger" data-pmb-delete data-delete-url="<?php echo e(route('admin.pmb.referrals.spp-rates.destroy', $rate->id)); ?>"><i class="ti ti-trash"></i> Hapus</button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table></div>
                <?php if($sppRates->isEmpty()): ?><div class="text-center text-muted py-3">Belum ada harga khusus. Pendaftar memakai tarif SPP standar PMB.</div><?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\pmb\resources\views\admin\pmb\sections\referrals.blade.php ENDPATH**/ ?>