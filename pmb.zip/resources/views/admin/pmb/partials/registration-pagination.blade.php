{{ $registrations->links() }}
